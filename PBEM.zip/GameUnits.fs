﻿module GameUnits

type UnitID private () =
    let mutable id = 0

    static let instance = UnitID ()

    static member Instance = instance

    member this.GetNextID () =
        id <- id + 1
        id

type Period =
    | Ancient = 0
    | DarkAges = 1
    | Medieval = 2
    | Pike = 3
    | Musket = 4
    | Rifle = 5
    | Machine = 6
    | Modern = 7

type UnitType =
    | Unknown = -1
    | Infantry = 0
    | Skirmishers = 1
    | Archers = 2
    | Cavalry = 3
    | Warband = 4
    | Knights = 5
    | Swordsmen = 6
    | Reiters = 7
    | Artillery = 8
    | Zouaves = 9
    | HeavyInfantry = 10
    | Mortars = 11
    | AntiTankGuns = 12
    | Tanks = 13

type Unit = {
    ID : int
    Name : string
    Type : UnitType
    Period : Period
    Hits : int
    //State : UnitState
}

let CreateUnit name unittype period =
    {
        ID = UnitID.Instance.GetNextID ()
        Name = name
        Type = unittype
        Period = period
        Hits = 15
    }
